# FYTRR TestFlight Readiness Checklist

## Already completed in code
- Yelp live data fallback key is embedded in `RestaurantService`.
- Apple Health authorization and metric reads are implemented in `HealthKitManager`.
- WHOOP UI is disabled for this TestFlight cycle.

## Required in Xcode before archive
1. Target `FYTRR 2026` -> `Signing & Capabilities`
- Add capability: `HealthKit`

2. Target `FYTRR 2026` -> `Info`
- Confirm `Privacy - Location When In Use Usage Description` exists
- Add `Privacy - Health Share Usage Description` with user-facing text

3. Target `FYTRR 2026` -> `General`
- Bump `Build` number (required for each new upload)

## Archive + Upload
1. Select `Any iOS Device (arm64)`
2. `Product` -> `Archive`
3. In Organizer: `Distribute App` -> `App Store Connect` -> `Upload`

## App Store Connect checks
- Add TestFlight internal testers
- Fill compliance/questions
- Add app privacy nutrition labels
- Add beta app description + feedback email

## Post-upload sanity tests (TestFlight)
- Location permission prompt appears and map search works
- Fuel list loads real restaurants near tester location
- DoorDash links open from map/list cards
- Apple Health connect flow shows status updates
- WHOOP is hidden/disabled in this build
